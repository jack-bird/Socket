<?php
/**
 * Created by PhpStorm.
 * User: wangl
 * Date: 2017/6/13
 * Time: 15:38
 */
use Workerman\Worker;
use Workerman\Lib\Timer;

require_once 'vendor/autoload.php';

//创建一个Worker监听127.0.0.1:8000, 使用websocket协议通讯
$ws_worker = new Worker("websocket://192.168.3.45:1920");

//启动4个进程对外提供服务
$ws_worker->count = 1;

$nameList = array();
$address = array();

$ws_worker->onConnect = function ($connection) use (&$nameList)
{
    $nameList[$connection->id] = "";
    $life = count($nameList)-1;
    $connection->send('当前在线用户'.$life.'人');
    $connection->send('连接成功请在聊天框，输入你的名字。');
};


//当接收到客户端发来的数据后显示数据并回发到客户端
$ws_worker->onMessage = function($connection, $data) use ($ws_worker, &$nameList, &$address) {
    $data = htmlspecialchars($data);
    if (empty($nameList[$connection->id])){
        if (!in_array($data, $nameList)){
            $nameList[$connection->id] = $data;
            foreach ($ws_worker->connections as $con){
                $con->send("Welcome $data");
            }
        } else {
            $connection->send("名字被占用了，换一个吧");
        }
    } else{
        if ($data == ":rylb"){
            $infos = "当前在线".count($nameList).'人:  ';
            foreach ($nameList as $key=>$value){
                $infos.=$value." | ";
            }
            $connection->send($infos);
        } else if ($data == ":rname"){
            $connection->send('输入你的新名字。');
        } else{
            //是否是给特定的发送消息
            $info = explode('@', $data);
            if (count($info)>1){
                $keys = array_search($info[0], $nameList);
                if ($keys){
                    $msg = '';
                    foreach ($info as $key=>$value){
                        if ($key!=0){
                            $msg.=$value;
                        }
                    }
                    $receive = $ws_worker->connections[$keys];
                    $receive->send($nameList[$connection->id].':'.$msg);
                    $connection->send($nameList[$connection->id].':'.$msg);
                }else{
                    $connection->send('没有该用户');
                }
            }else{
                foreach ($ws_worker->connections as $con){
                    $con->send($nameList[$connection->id].':'.$data);
                }
            }
        }
    }
};

//当客户端断开
$ws_worker->onClose = function ($connection) use ($ws_worker, &$nameList)
{
    foreach ($ws_worker->connections as $con){
        $con->send('['.$nameList[$connection->id].']'.'离开了');
    }
    unset($nameList[$connection->id]);
};

//运行worker
$ws_worker->runAll();
